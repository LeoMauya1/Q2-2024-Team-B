# 3D-Template

The following is a template you must fork when creating a 3D project in the video game design class. If working with team members, you must share the forked repository with them so they can work on the copy of the repository and not the original.
