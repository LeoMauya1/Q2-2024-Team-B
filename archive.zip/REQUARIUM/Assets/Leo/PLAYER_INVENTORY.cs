using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PLAYER_INVENTORY : MonoBehaviour
{
   public List<GameObject> Inventory = new List<GameObject>();
}
